
# =============================================================
#  EV ChargeOps - Sistema Inteligente de Gerenciamento
#  Desafio Academico FIAP + GoodWe | EV Challenge 2026
#  Sprint 3 - Estruturas de Dados, Busca, Ordenacao e Complexidade
# =============================================================

import time
import random
from datetime import datetime

# --- Constantes ----------------------------------------------
TARIFA_BASE_KWH         = 0.85
TARIFA_PICO_KWH         = 1.25
TARIFA_FORA_PICO_KWH    = 0.65
TAXA_SERVICO            = 1.50
LIMITE_POTENCIA_REDE_KW = 22.0
MAX_CARREGADORES        = 5

TIPOS_USUARIO = {
    "1": {"nome": "Morador",     "desconto": 0.10, "label": "Morador     (10% desc)"},
    "2": {"nome": "Visitante",   "desconto": 0.00, "label": "Visitante   (sem desc)"},
    "3": {"nome": "Funcionário", "desconto": 0.15, "label": "Funcionário (15% desc)"},
}

CARREGADORES = {
    1: {"potencia_max": 7.4,  "modelo": "GoodWe HCA G2 7kW"},
    2: {"potencia_max": 11.0, "modelo": "GoodWe HCA G2 11kW"},
    3: {"potencia_max": 22.0, "modelo": "GoodWe HCA G2 22kW"},
    4: {"potencia_max": 7.4,  "modelo": "GoodWe HCA G2 7kW"},
    5: {"potencia_max": 11.0, "modelo": "GoodWe HCA G2 11kW"},
}


# =============================================================
#  ESTRUTURA DE DADOS DA SESSAO (NOVO - SPRINT 3)
# =============================================================

class Sessao:
    """Representa uma sessao de recarga ja concluida (historico)."""

    def __init__(self, numero, id_sessao, carregador_id, modelo, usuario,
                 tipo, placa, inicio, fim, duracao_min, potencia,
                 status_demanda, energia_kwh, faixa, tarifa_base,
                 tarifa_final, desconto, custo_energia, taxa_servico, total):
        self.numero         = numero          # ID simples e sequencial (novo - usado em busca/ordenacao)
        self.id_sessao      = id_sessao        # ID técnico do OCPP
        self.carregador_id  = carregador_id
        self.modelo         = modelo
        self.usuario        = usuario
        self.tipo           = tipo
        self.placa          = placa
        self.inicio         = inicio
        self.fim            = fim
        self.duracao_min    = duracao_min      # novo - tempo de recarga, em minutos
        self.potencia       = potencia
        self.status_demanda = status_demanda
        self.energia_kwh    = energia_kwh
        self.faixa          = faixa
        self.tarifa_base    = tarifa_base
        self.tarifa_final   = tarifa_final
        self.desconto       = desconto
        self.custo_energia  = custo_energia
        self.taxa_servico   = taxa_servico
        self.total          = total


# --- Estado global do sistema --------------------------------
sessoes_ativas    = {}   # carregador_id -> dados da sessao (dict, sessao em andamento)
historico_sessoes = []   # lista de objetos Sessão, sessões ja encerradas
log_ocpp          = []   # registro de mensagens do protocólo

proximo_numero_sessao = 1


# =============================================================
#  UTILITÁRIOS
# =============================================================

def linha_simples():
    print("-" * 65)

def linha_dupla():
    print("=" * 65)

def cabecalho(titulo):
    linha_dupla()
    print("  " + titulo)
    linha_dupla()

def secao(titulo):
    linha_simples()
    print("  " + titulo)
    linha_simples()

def pausar():
    print()
    input("  Pressione ENTER para continuar...")
    print()

def entrada_inteira(mensagem, minimo, maximo):
    while True:
        try:
            valor = int(input(mensagem))
            if minimo <= valor <= maximo:
                return valor
            print("  [!] Digite um número entre " + str(minimo) + " e " + str(maximo))
        except ValueError:
            print("  [!] Somente números inteiros sao aceitos.")

def entrada_float(mensagem, minimo, maximo):
    while True:
        try:
            valor = float(input(mensagem))
            if minimo <= valor <= maximo:
                return valor
            print("  [!] Digite um valor entre " + str(minimo) + " e " + str(maximo))
        except ValueError:
            print("  [!] Use ponto decimal. Exemplo: 7.4")


# =============================================================
#  OCPP - SIMULAÇÃO DE PROTOCOLO DE COMUNICACAO
# =============================================================

def ocpp_enviar(acao, payload):
    """
    Simula o envio de uma mensagem no protocólo OCPP 1.6.
    OCPP (Open Charge Point Protocol) e o protocolo real
    usado por eletropostos para comunicar com servidores.
    Formato: [tipo, id_unico, acao, payload]
    """
    timestamp  = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    msg_id     = "MSG-" + datetime.now().strftime("%H%M%S%f")[:10]
    mensagem   = {
        "tipo"     : "CALL",
        "id"       : msg_id,
        "acao"     : acao,
        "timestamp": timestamp,
        "payload"  : payload,
    }
    log_ocpp.append(mensagem)
    print("  [OCPP >>] " + acao + " | ID: " + msg_id)
    time.sleep(0.3)
    return msg_id

def ocpp_receber(msg_id, resultado):
    """Simula o recebimento da resposta do servidor OCPP."""
    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    resposta  = {
        "tipo"     : "CALLRESULT",
        "id"       : msg_id,
        "timestamp": timestamp,
        "resultado": resultado,
    }
    log_ocpp.append(resposta)
    print("  [OCPP <<] " + resultado + " | REF: " + msg_id)
    time.sleep(0.2)

def ocpp_boot_notification():
    """Notifica o servidor que o sistema foi iniciado."""
    secao("OCPP - BootNotification")
    print("  Registrando sistema na plataforma GoodWe SEMS...")
    print()
    mid = ocpp_enviar("BootNotification", {
        "chargePointVendor" : "GoodWe",
        "chargePointModel"  : "HCA-G2-Multi",
        "chargePointSerial" : "GW2026FIAP001",
        "firmwareVersion"   : "2.1.4",
    })
    ocpp_receber(mid, "Accepted")
    print()
    print("  Sistema registrado com sucesso na plataforma.")

def ocpp_status_notification(carregador_id, status):
    """Notifica mudanca de status de um carregador."""
    mid = ocpp_enviar("StatusNotification", {
        "connectorId": carregador_id,
        "status"     : status,
        "timestamp"  : datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
    })
    ocpp_receber(mid, "Accepted")

def ocpp_start_transaction(carregador_id, usuario, potencia):
    """Notifica inicio de transacao de recarga."""
    mid = ocpp_enviar("StartTransaction", {
        "connectorId"  : carregador_id,
        "idTag"        : usuario,
        "meterStart"   : 0,
        "timestamp"    : datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "powerLimit"   : str(potencia) + "kW",
    })
    ocpp_receber(mid, "Accepted")
    return mid

def ocpp_stop_transaction(carregador_id, energia_kwh, custo):
    """Notifica encerramento de transacao."""
    mid = ocpp_enviar("StopTransaction", {
        "connectorId"  : carregador_id,
        "meterStop"    : round(energia_kwh * 1000),
        "totalCost"    : "R$ " + str(custo),
        "timestamp"    : datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "reason"       : "Local",
    })
    ocpp_receber(mid, "Accepted")

def ocpp_meter_values(carregador_id, energia_kwh, potencia_atual):
    """Envia leitura de medidor durante recarga (telemetria)."""
    mid = ocpp_enviar("MeterValues", {
        "connectorId"   : carregador_id,
        "energyKwh"     : round(energia_kwh, 3),
        "powerKw"       : round(potencia_atual, 2),
        "timestamp"     : datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
    })
    ocpp_receber(mid, "Accepted")


# =============================================================
#  CONTROLE DE DEMANDA
# =============================================================

def calcular_carga_total():
    """Soma a potência de todas as sessões ativas."""
    total = 0.0
    for s in sessoes_ativas.values():
        total += s["potência_aprovada"]
    return round(total, 2)

def calcular_potencia_disponivel():
    """Retorna quanto ainda pode ser alocado na rede."""
    return round(LIMITE_POTENCIA_REDE_KW - calcular_carga_total(), 2)

def aplicar_controle_demanda(potencia_solicitada):
    """
    Controle inteligente de demanda:
    Verifica se a rede suporta mais carga.
    Se nao, redistribui ou limita de forma proporcional.
    """
    disponivel = calcular_potencia_disponivel()

    if potencia_solicitada <= disponivel:
        return potencia_solicitada, "OK", None

    elif disponivel > 0.5:
        # Aprova o que sobrou, mas avisa
        return round(disponivel, 2), "LIMITADA", disponivel

    else:
        # Verifica se pode redistribuir reduzindo sessoes ativas
        if len(sessoes_ativas) > 0:
            reducao_por_sessao = round(
                (potencia_solicitada - disponivel) / len(sessoes_ativas), 2
            )
            return potencia_solicitada, "REDISTRIBUIDA", reducao_por_sessao
        else:
            return 0, "BLOQUEADA", None

def redistribuir_potencia(reducao):
    """
    Reduz a potência de todas as sessões ativas proporcionalmente
    para acomodar um novo carregamento.
    """
    print()
    print("  [DEMANDA] Redistribuindo potência entre sessões ativas...")
    for cid, sessao in sessoes_ativas.items():
        nova = max(1.0, round(sessao["potência_aprovada"] - reducao, 2))
        sessoes_ativas[cid]["potência_aprovada"] = nova
        print("  [DEMANDA] Carregador " + str(cid) + ": " +
              str(sessao["potência_aprovada"]) + " kW -> " + str(nova) + " kW")
        ocpp_status_notification(cid, "ChargingAdjusted")
    print()


# =============================================================
#  TARIFACAO DINÂMICA
# =============================================================

def detectar_horario(hora):
    if 18 <= hora <= 20:
        return "pico"
    elif hora >= 23 or hora <= 5:
        return "fora_pico"
    else:
        return "normal"

def calcular_tarifa_dinamica(hora, tipo_key, carga_percentual):
    """
    Tarifacao dinamica: combina horario + tipo de usuario
    + percentual de carga atual da rede (demanda em tempo real).
    Quanto mais carregada a rede, maior o ajuste na tarifa.
    """
    faixa = detectar_horario(hora)

    if faixa == "pico":
        tarifa = TARIFA_PICO_KWH
        label  = "Pico (18h-21h)"
    elif faixa == "fora_pico":
        tarifa = TARIFA_FORA_PICO_KWH
        label  = "Fora de Pico (23h-06h)"
    else:
        tarifa = TARIFA_BASE_KWH
        label  = "Normal"

    # Ajuste dinamico por demanda da rede
    if carga_percentual >= 80:
        ajuste = 0.20
        label += " + alta demanda (+20%)"
    elif carga_percentual >= 50:
        ajuste = 0.10
        label += " + media demanda (+10%)"
    else:
        ajuste = 0.0

    tarifa = tarifa * (1 + ajuste)

    desconto     = TIPOS_USUARIO[tipo_key]["desconto"]
    tarifa_final = round(tarifa * (1 - desconto), 4)

    return tarifa_final, label, round(tarifa, 4), desconto


# =============================================================
#  PAINEL DE STATUS
# =============================================================

def exibir_painel_status():
    cabecalho("PAINEL DE STATUS - EV ChargeOps")

    carga_total = calcular_carga_total()
    disponivel  = calcular_potencia_disponivel()
    percentual  = round((carga_total / LIMITE_POTENCIA_REDE_KW) * 100, 1)

    barras = int(percentual / 5)
    barra  = "#" * barras + "." * (20 - barras)

    print("  Rede: [" + barra + "] " + str(percentual) + "%")
    print("  Carga total   : " + str(carga_total) + " kW  /  " +
          str(LIMITE_POTENCIA_REDE_KW) + " kW")
    print("  Disponível    : " + str(disponivel) + " kW")
    print("  Sessões ativas: " + str(len(sessoes_ativas)))
    print("  Histórico     : " + str(len(historico_sessoes)) + " sessoes concluidas")
    linha_simples()

    if len(sessoes_ativas) == 0:
        print("  Nenhuma sessão ativa no momento.")
    else:
        print("  SLOT  USUÁRIO          PLACA     kW    INICIO")
        linha_simples()
        for cid, s in sessoes_ativas.items():
            print("  [C" + str(cid) + "]  " +
                  s["usuário"][:16].ljust(16) + "  " +
                  s["placa"].upper().ljust(8) + "  " +
                  str(s["potência_aprovada"]).ljust(5) + " " +
                  s["início"])

    linha_dupla()


# =============================================================
#  INICIAR SESSÃO
# =============================================================

def iniciar_sessao():
    cabecalho("INICIAR NOVA SESSÃO DE RECARGA")

    # Verifica carregadores disponiveis
    ocupados = list(sessoes_ativas.keys())
    livres   = [c for c in CARREGADORES if c not in ocupados]

    if not livres:
        print("  [!] Todos os carregadores estão ocupados.")
        pausar()
        return

    print("  Carregadores disponíveis:")
    for c in livres:
        print("    [" + str(c) + "] " + CARREGADORES[c]["modelo"] +
              " - até " + str(CARREGADORES[c]["potência_max"]) + " kW")
    print()

    cid = entrada_inteira("  Escolha o carregador: ", 1, MAX_CARREGADORES)
    if cid not in livres:
        print("  [!] Carregador " + str(cid) + " está ocupado.")
        pausar()
        return

    secao("DADOS DO USUÁRIO")

    nome = input("  Nome do usuário: ").strip()
    while not nome:
        print("  [!] Nome não pode ser vazio.")
        nome = input("  Nome do usuário: ").strip()

    placa = input("  Placa do veículo: ").strip()
    while len(placa) < 5:
        print("  [!] Placa inválida.")
        placa = input("  Placa do veículo: ").strip()

    print()
    print("  Tipo de Usuário:")
    for k, v in TIPOS_USUARIO.items():
        print("    [" + k + "] " + v["label"])

    tipo = ""
    while tipo not in TIPOS_USUARIO:
        tipo = input("  Selecione [1/2/3]: ").strip()
        if tipo not in TIPOS_USUARIO:
            print("  [!] Opção inválida.")

    secao("PARAMETROS DA SESSÃO")

    hora       = entrada_inteira("  Hora atual (0-23): ", 0, 23)
    pot_max    = CARREGADORES[cid]["potência_max"]
    potencia_s = entrada_float(
        "  Potência desejada em kW (1.0-" + str(pot_max) + "): ", 1.0, pot_max
    )

    # Controle de demanda
    carga_atual  = calcular_carga_total()
    percentual   = round((carga_atual / LIMITE_POTENCIA_REDE_KW) * 100, 1)
    pot_ap, status_d, dado_extra = aplicar_controle_demanda(potencia_s)

    print()
    print("  [DEMANDA] Carga atual: " + str(carga_atual) + " kW (" +
          str(percentual) + "% da rede)")

    if status_d == "BLOQUEADA":
        print("  [X] Rede sem capacidade. Tente mais tarde.")
        ocpp_status_notification(cid, "Faulted")
        pausar()
        return

    if status_d == "LIMITADA":
        print("  [!] Potência limitada a " + str(pot_ap) + " kW.")

    if status_d == "REDISTRIBUIDA":
        print("  [!] Redistribuindo carga entre sessões ativas...")
        redistribuir_potencia(dado_extra)
        pot_ap = potencia_s

    # Tarifação dinâmica
    tarifa_f, faixa, tarifa_b, desc = calcular_tarifa_dinamica(
        hora, tipo, percentual
    )

    secao("CONFIRMAÇÃO")
    print("  Carregador : " + str(cid) + " - " + CARREGADORES[cid]["modelo"])
    print("  Usuário    : " + nome)
    print("  Placa      : " + placa.upper())
    print("  Potência   : " + str(pot_ap) + " kW  [" + status_d + "]")
    print("  Faixa      : " + faixa)
    print("  Tarifa     : R$ " + str(tarifa_f) + "/kWh")
    print()

    ok = input("  Confirmar início? [S/N]: ").strip().upper()
    if ok != "S":
        print("  Sessão cancelada.")
        pausar()
        return

    # Registra sessao ativa
    inicio = datetime.now()
    ocpp_status_notification(cid, "Preparing")
    mid_start = ocpp_start_transaction(cid, nome, pot_ap)

    sessoes_ativas[cid] = {
        "id_sessão"      : "CGS-" + inicio.strftime("%Y%m%d%H%M%S") + "-C" + str(cid),
        "carregador_id"  : cid,
        "usuario"        : nome,
        "tipo"           : tipo,
        "placa"          : placa,
        "hora_tarifãcao" : hora,
        "potência_solicitada": potencia_s,
        "potência_aprovada"  : pot_ap,
        "status_demanda" : status_d,
        "faixa"          : faixa,
        "tarifa_base"    : tarifa_b,
        "tarifa_final"   : tarifa_f,
        "desconto"       : desc,
        "energia_kwh"    : 0.0,
        "início"         : inicio.strftime("%H:%M:%S"),
        "início_dt"      : inicio,
        "ocpp_start_id"  : mid_start,
    }

    ocpp_status_notification(cid, "Charging")
    print()
    print("  [OK] Sessão iniciada no carregador " + str(cid) + "!")
    pausar()


# =============================================================
#  ATUALIZAR SESSÕES (SIMULA PASSAGEM DE TEMPO)
# =============================================================

def atualizar_sessoes():
    if not sessoes_ativas:
        print()
        print("  Nenhuma sessão ativa para atualizar.")
        pausar()
        return

    cabecalho("SIMULAR PROGRESSO DAS SESSÕES")
    minutos = entrada_inteira(
        "  Quantos minutos simular? (1-60): ", 1, 60
    )

    print()
    print("  Simulando " + str(minutos) + " minuto(s) de recarga...")
    print()

    for cid, sessao in sessoes_ativas.items():
        energia_gerada = 0.0
        pot = sessao["potência_aprovada"]

        for m in range(minutos):
            fator          = random.uniform(0.95, 1.00)
            energia_gerada += (pot * fator) / 60
            time.sleep(0.01)

        sessoes_ativas[cid]["energia_kwh"] = round(
            sessao["energia_kwh"] + energia_gerada, 3
        )

        custo_parcial = round(
            sessoes_ativas[cid]["energia_kwh"] * sessao["tarifa_final"], 2
        )

        print("  Carregador " + str(cid) + " | " + sessao["usuário"])
        print("    Energia acumulada : " +
              str(sessoes_ativas[cid]["energia_kwh"]) + " kWh")
        print("    Custo parcial     : R$ " + str(custo_parcial))
        print()

        # Envia telemetria via OCPP
        ocpp_meter_values(cid, sessoes_ativas[cid]["energia_kwh"], pot)

    pausar()


# =============================================================
#  ENCERRAR SESSAO
# =============================================================

def encerrar_sessao():
    global proximo_numero_sessao

    if not sessoes_ativas:
        print()
        print("  Nenhuma sessão ativa para encerrar.")
        pausar()
        return

    cabecalho("ENCERRAR SESSÃO DE RECARGA")

    print("  Sessoes ativas:")
    for cid, s in sessoes_ativas.items():
        print("    [" + str(cid) + "] " + s["usuário"] +
              " | " + s["placa"].upper() +
              " | " + str(s["energia_kwh"]) + " kWh")
    print()

    cid = entrada_inteira(
        "  Escolha o carregador para encerrar: ", 1, MAX_CARREGADORES
    )
    if cid not in sessoes_ativas:
        print("  [!] Carregador " + str(cid) + " não está ativo.")
        pausar()
        return

    sessao = sessoes_ativas[cid]
    fim    = datetime.now()

    custo_e = round(sessao["energia_kwh"] * sessao["tarifa_final"], 2)
    total   = round(custo_e + TAXA_SERVICO, 2)
    duracao = round((fim - sessao["inicio_dt"]).total_seconds() / 60, 1)

    # Envia encerramento via OCPP
    ocpp_stop_transaction(cid, sessao["energia_kwh"], total)
    ocpp_status_notification(cid, "Available")

    # Monta o registro final como objeto Sessao (NOVO - Sprint 3, antes era dict)
    registro = Sessao(
        numero         = proximo_numero_sessao,
        id_sessao      = sessao["id_sessao"],
        carregador_id  = cid,
        modelo         = CARREGADORES[cid]["modelo"],
        usuario        = sessao["usuario"],
        tipo           = sessao["tipo"],
        placa          = sessao["placa"],
        inicio         = sessao["inicio"],
        fim            = fim.strftime("%H:%M:%S"),
        duracao_min    = duracao,
        potencia       = sessao["potencia_aprovada"],
        status_demanda = sessao["status_demanda"],
        energia_kwh    = sessao["energia_kwh"],
        faixa          = sessao["faixa"],
        tarifa_base    = sessao["tarifa_base"],
        tarifa_final   = sessao["tarifa_final"],
        desconto       = sessao["desconto"],
        custo_energia  = custo_e,
        taxa_servico   = TAXA_SERVICO,
        total          = total,
    )

    historico_sessoes.append(registro)
    proximo_numero_sessao += 1
    del sessoes_ativas[cid]

    # Exibe relatorio da sessao encerrada
    print()
    cabecalho("RELATORIO DA SESSÃO ENCERRADA")
    print("  Numero (ID)    : " + str(registro.numero))
    print("  ID Tecnico     : " + registro.id_sessao)
    print("  Carregador     : C" + str(cid) + " - " + registro.modelo)
    print("  Usuario        : " + registro.usuario)
    print("  Tipo           : " + TIPOS_USUARIO[registro.tipo]["label"])
    print("  Placa          : " + registro.placa.upper())
    linha_simples()
    print("  Inicio         : " + registro.inicio)
    print("  Fim            : " + registro.fim)
    print("  Duracao        : " + str(registro.duracao_min) + " min")
    print("  Potencia       : " + str(registro.potencia) + " kW")
    print("  Energia        : " + str(registro.energia_kwh) + " kWh")
    linha_simples()
    print("  Faixa          : " + registro.faixa)
    print("  Tarifa Base    : R$ " + str(registro.tarifa_base) + "/kWh")
    if registro.desconto > 0:
        print("  Desconto       : " + str(int(registro.desconto * 100)) + "%")
    print("  Tarifa Final   : R$ " + str(registro.tarifa_final) + "/kWh")
    linha_simples()
    print("  Custo Energia  : R$ " + str(registro.custo_energia))
    print("  Taxa Servico   : R$ " + str(registro.taxa_servico))
    print("  " + "-" * 35)
    print("  TOTAL COBRADO  : R$ " + str(registro.total))
    linha_dupla()
    print("  Status: SESSÃO ENCERRADA COM SUCESSO")
    linha_dupla()
    pausar()


# =============================================================
#  RELATORIO GERAL
# =============================================================

def exibir_relatorio_geral():
    cabecalho("RELATÓRIO GERAL DO SISTEMA")

    if not historico_sessoes and not sessoes_ativas:
        print("  Nenhuma sessão registrada ainda.")
        pausar()
        return

    # Resumo financeiro
    total_energia = sum(s.energia_kwh for s in historico_sessoes)
    total_receita = sum(s.total       for s in historico_sessoes)
    total_sessoes = len(historico_sessoes)

    print("  Total de sessões concluídas : " + str(total_sessoes))
    print("  Energia total entregue      : " + str(round(total_energia, 3)) + " kWh")
    print("  Receita total               : R$ " + str(round(total_receita, 2)))
    linha_simples()

    if historico_sessoes:
        print("  HISTÓRICO DE SESSÕES:")
        print()
        print("  NUM  USUÁRIO          kWh    TOTAL")
        linha_simples()
        for s in historico_sessoes:
            print("  " + str(s.numero).rjust(3) + "  " +
                  s.usuario[:14].ljust(14) + "  " +
                  str(s.energia_kwh).ljust(6) + " R$ " +
                  str(s.total))

    linha_simples()

    if sessoes_ativas:
        print()
        print("  SESSÕES AINDA ATIVAS:")
        for cid, s in sessoes_ativas.items():
            custo_p = round(s["energia_kwh"] * s["tarifa_final"], 2)
            print("  C" + str(cid) + " | " + s["usuario"] +
                  " | " + str(s["energia_kwh"]) + " kWh" +
                  " | R$ " + str(custo_p) + " (parcial)")

    linha_dupla()
    pausar()


# =============================================================
#  LOG OCPP
# =============================================================

def exibir_log_ocpp():
    cabecalho("LOG DE MENSAGENS OCPP")

    if not log_ocpp:
        print("  Nenhuma mensagem registrada.")
        pausar()
        return

    print("  Total de mensagens: " + str(len(log_ocpp)))
    linha_simples()

    for msg in log_ocpp[-20:]:   # mostra as ultimas 20
        if msg["tipo"] == "CALL":
            print("  >> [" + msg["timestamp"] + "] " +
                  msg["acao"] + " | ID: " + msg["id"])
            for k, v in msg["payload"].items():
                print("       " + k + ": " + str(v))
        else:
            print("  << RESULT [" + msg["timestamp"] + "] " +
                  msg["resultado"] + " | REF: " + msg["id"])
        print()

    if len(log_ocpp) > 20:
        print("  ... e mais " + str(len(log_ocpp) - 20) + " mensagem(ns) anteriores.")

    linha_dupla()
    pausar()


# =============================================================
#  BUSCA, ORDENACAO E ESTATÍSTICAS DO HISTÓRICO (NOVO - SPRINT 3)
# =============================================================

def busca_sequencial_por_numero(lista, numero_procurado):
    """
    Busca sequencial (linear) pelo atributo 'numero' de cada Sessao.
    Percorre a lista posicao por posicao ate encontrar o elemento
    ou concluir que ele nao existe.

    Complexidade: O(n) -- no pior caso (numero inexistente, ou na
    ultima posicao) o codigo percorre as n posicoes da lista uma
    unica vez. Esse crescimento vem do 'for i in range(len(lista))'
    abaixo: dobrar o tamanho da lista dobra, no pior caso, a
    quantidade de comparacoes feitas.
    """
    for i in range(len(lista)):
        if lista[i].numero == numero_procurado:
            return i
    return -1


def bubble_sort_sessoes(lista, criterio):
    """
    Ordenacao por Bubble Sort, implementada manualmente (sem usar
    sort()/sorted()), ordenando a lista de objetos Sessao IN-PLACE
    conforme o criterio escolhido pelo usuario.

    criterio pode ser: "numero", "energia_kwh", "total" ou "duracao_min".

    Complexidade: O(n^2) -- os dois 'for' aninhados abaixo fazem com
    que, no pior caso, o numero de comparacoes cresca de forma
    aproximadamente quadratica (n * (n-1) / 2 comparacoes). Se a
    quantidade de sessoes dobrar, o numero de comparacoes cresce
    cerca de 4 vezes, nao 2.
    """
    n = len(lista)

    for i in range(n):
        for j in range(n - 1 - i):
            valor_atual   = getattr(lista[j],     criterio)
            valor_proximo = getattr(lista[j + 1], criterio)

            if valor_atual > valor_proximo:
                lista[j], lista[j + 1] = lista[j + 1], lista[j]


def listar_sessoes():
    cabecalho("HISTÓRICO DE SESSÕES (LISTA COMPLETA)")

    if not historico_sessoes:
        print("  Nenhuma sessão no histÓrico ainda.")
        pausar()
        return

    print("  Total de sessões no histórico: " + str(len(historico_sessoes)))
    linha_simples()
    print("  NUM  USUÁRIO          ENERGIA(kWh)  DURAÇÃO(min)  TOTAL(R$)")
    linha_simples()

    for s in historico_sessoes:
        print("  " + str(s.numero).rjust(3) + "  " +
              s.usuario[:16].ljust(16) + "  " +
              str(s.energia_kwh).rjust(10) + "    " +
              str(s.duracao_min).rjust(9) + "     " +
              str(s.total))

    linha_dupla()
    pausar()


def buscar_sessao_menu():
    cabecalho("BUSCAR SESSÃO POR NÚMERO (ID)")

    if not historico_sessoes:
        print("  Nenhuma sessão no histórico ainda.")
        pausar()
        return

    numero = entrada_inteira("  Digite o número (ID) da sessão: ", 1, 999999)

    indice = busca_sequencial_por_numero(historico_sessoes, numero)

    if indice == -1:
        print()
        print("  [!] Sessão número " + str(numero) + " não encontrada.")
        pausar()
        return

    s = historico_sessoes[indice]
    print()
    secao("SESSÃO ENCONTRADA")
    print("  Numero (ID)    : " + str(s.numero))
    print("  ID Técnico     : " + s.id_sessao)
    print("  Usuário        : " + s.usuario)
    print("  Placa          : " + s.placa.upper())
    print("  Início / Fim   : " + s.inicio + " -> " + s.fim)
    print("  Duração        : " + str(s.duracao_min) + " min")
    print("  Energia        : " + str(s.energia_kwh) + " kWh")
    print("  Total cobrado  : R$ " + str(s.total))
    linha_dupla()
    pausar()


def ordenar_sessoes_menu():
    cabecalho("ORDENAR SESSÕES DO HISTÓRICO")

    if len(historico_sessoes) < 2:
        print("  E preciso pelo menos 2 sessões no histórico para ordenar.")
        pausar()
        return

    print("  Ordenar por:")
    print("    [1] Numero (ID)")
    print("    [2] Energia consumida")
    print("    [3] Custo total")
    print("    [4] Duração (tempo de recarga)")
    print()

    opcao = entrada_inteira("  Escolha: ", 1, 4)

    criterios = {
        1: "número",
        2: "energia_kwh",
        3: "total",
        4: "duração_min",
    }

    bubble_sort_sessoes(historico_sessoes, criterios[opcao])

    print()
    print("  [OK] Histórico ordenado por " + criterios[opcao] + ".")
    pausar()

    listar_sessoes()


def mostrar_estatisticas():
    cabecalho("ESTATÍSTICAS DA ESTAÇÃO")

    if not historico_sessoes:
        print("  Nenhuma sessão no histórico ainda.")
        pausar()
        return

    quantidade = len(historico_sessoes)

    energia_total = 0.0
    faturamento   = 0.0
    maior_consumo = historico_sessoes[0].energia_kwh
    menor_consumo = historico_sessoes[0].energia_kwh

    for s in historico_sessoes:
        energia_total += s.energia_kwh
        faturamento   += s.total

        if s.energia_kwh > maior_consumo:
            maior_consumo = s.energia_kwh
        if s.energia_kwh < menor_consumo:
            menor_consumo = s.energia_kwh

    custo_medio = round(faturamento / quantidade, 2)

    print("  Sessões realizadas : " + str(quantidade))
    print("  Energia fornecida  : " + str(round(energia_total, 2)) + " kWh")
    print("  Faturamento        : R$ " + str(round(faturamento, 2)))
    print("  Ticket médio       : R$ " + str(custo_medio))
    print("  Maior consumo      : " + str(maior_consumo) + " kWh")
    print("  Menor consumo      : " + str(menor_consumo) + " kWh")
    linha_dupla()
    pausar()


# =============================================================
#  CENÁRIO AUTOMATICO (DEMO)
# =============================================================

def executar_cenario_demo():
    global proximo_numero_sessao

    cabecalho("CENÁRIO AUTOMÁTICO - DEMO")
    print("  Este cenário simula automaticamente 3 veículos")
    print("  conectando, carregando e desconectando.")
    print()
    input("  Pressione ENTER para iniciar o demo...")
    print()

    veiculos = [
        {"nome": "Carlos Lima",   "placa": "EVO1A23", "tipo": "1", "cid": 1, "pot": 7.4,  "hora": 14},
        {"nome": "Ana Souza",     "placa": "BEV2B34", "tipo": "2", "cid": 2, "pot": 11.0, "hora": 19},
        {"nome": "Pedro Martins", "placa": "ZEV3C45", "tipo": "3", "cid": 3, "pot": 7.4,  "hora": 23},
    ]

    # Inicia as 3 sessoes
    for v in veiculos:
        secao("Conectando: " + v["nome"])
        carga_atual = calcular_carga_total()
        pct         = round((carga_atual / LIMITE_POTENCIA_REDE_KW) * 100, 1)
        pot_ap, status, extra = aplicar_controle_demanda(v["pot"])

        if status == "REDISTRÍBUIDA":
            redistribuir_potencia(extra)
            pot_ap = v["pot"]

        tarifa_f, faixa, tarifa_b, desc = calcular_tarifa_dinamica(
            v["hora"], v["tipo"], pct
        )

        inicio = datetime.now()
        ocpp_status_notification(v["cid"], "Preparing")
        mid = ocpp_start_transaction(v["cid"], v["nome"], pot_ap)
        ocpp_status_notification(v["cid"], "Charging")

        sessoes_ativas[v["cid"]] = {
            "id_sessao"          : "CGS-" + inicio.strftime("%Y%m%d%H%M%S") + "-C" + str(v["cid"]),
            "carregador_id"      : v["cid"],
            "usuario"            : v["nome"],
            "tipo"               : v["tipo"],
            "placa"              : v["placa"],
            "hora_tarifacao"     : v["hora"],
            "potencia_solicitada": v["pot"],
            "potencia_aprovada"  : pot_ap,
            "status_demanda"     : status,
            "faixa"              : faixa,
            "tarifa_base"        : tarifa_b,
            "tarifa_final"       : tarifa_f,
            "desconto"           : desc,
            "energia_kwh"        : 0.0,
            "inicio"             : inicio.strftime("%H:%M:%S"),
            "inicio_dt"          : inicio,
            "ocpp_start_id"      : mid,
        }

        print("  [OK] " + v["nome"] + " conectado no C" + str(v["cid"]) +
              " | " + str(pot_ap) + " kW | " + faixa)
        time.sleep(0.5)

    exibir_painel_status()

    # Simula 30 minutos de recarga para todos
    secao("Simulando 30 minutos de recarga...")
    for cid, sessao in sessoes_ativas.items():
        energia = 0.0
        for m in range(30):
            energia += (sessao["potência_aprovada"] * random.uniform(0.95, 1.0)) / 60
        sessoes_ativas[cid]["energia_kwh"] = round(energia, 3)
        ocpp_meter_values(cid, sessoes_ativas[cid]["energia_kwh"],
                          sessao["potencia_aprovada"])
        print("  C" + str(cid) + " | " + sessao["usuario"] +
              " | " + str(sessoes_ativas[cid]["energia_kwh"]) + " kWh")
        time.sleep(0.3)

    # Encerra todas as sessoes
    secao("Encerrando todas as sessões...")
    for cid in list(sessoes_ativas.keys()):
        sessao  = sessoes_ativas[cid]
        fim     = datetime.now()
        custo_e = round(sessao["energia_kwh"] * sessao["tarifa_final"], 2)
        total   = round(custo_e + TAXA_SERVICO, 2)
        duracao = round((fim - sessao["inicio_dt"]).total_seconds() / 60, 1)

        ocpp_stop_transaction(cid, sessao["energia_kwh"], total)
        ocpp_status_notification(cid, "Available")

        registro = Sessao(
            numero         = proximo_numero_sessao,
            id_sessao      = sessao["id_sessao"],
            carregador_id  = cid,
            modelo         = CARREGADORES[cid]["modelo"],
            usuario        = sessao["usuario"],
            tipo           = sessao["tipo"],
            placa          = sessao["placa"],
            inicio         = sessao["inicio"],
            fim            = fim.strftime("%H:%M:%S"),
            duracao_min    = duracao,
            potencia       = sessao["potencia_aprovada"],
            status_demanda = sessao["status_demanda"],
            energia_kwh    = sessao["energia_kwh"],
            faixa          = sessao["faixa"],
            tarifa_base    = sessao["tarifa_base"],
            tarifa_final   = sessao["tarifa_final"],
            desconto       = sessao["desconto"],
            custo_energia  = custo_e,
            taxa_servico   = TAXA_SERVICO,
            total          = total,
        )
        historico_sessoes.append(registro)
        proximo_numero_sessao += 1

        print("  C" + str(cid) + " | " + sessao["usuario"] +
              " | Total: R$ " + str(total))

    sessoes_ativas.clear()
    print()
    print("  Demo concluido! Confira o Relatório Geral no menu.")
    pausar()


# =============================================================
#  MENU PRINCIPAL
# =============================================================

def menu_principal():
    while True:
        cabecalho("EV ChargeOps - Sistema de Gerenciamento")
        print("  FIAP + GoodWe | EV Challenge 2026 | Sprint 3")
        print()
        print("  Rede: " + str(calcular_carga_total()) + " kW em uso  |  " +
              str(calcular_potencia_disponivel()) + " kW disponivel  |  " +
              str(len(sessoes_ativas)) + " sessao(es) ativa(s)")
        print()
        linha_simples()
        print("  SESSOES")
        print("    [1] Iniciar nova sessão de recarga")
        print("    [2] Atualizar sessões (simular tempo)")
        print("    [3] Encerrar sessão")
        print()
        print("  MONITORAMENTO")
        print("    [4] Painel de status geral")
        print("    [5] Relatório consolidado")
        print("    [6] Log de mensagens OCPP")
        print()
        print("  HISTORICO")
        print("    [7] Listar sessões do histórico")
        print("    [8] Buscar sessão por número (ID)")
        print("    [9] Ordenar sessões do histórico")
        print("    [10] Estatísticas da estação")
        print()
        print("  DEMO")
        print("    [11] Executar cenário automático (3 veículos)")
        print()
        print("    [0] Sair")
        linha_simples()

        opcao = input("  Escolha uma opção: ").strip()

        if opcao == "1":
            iniciar_sessao()
        elif opcao == "2":
            atualizar_sessoes()
        elif opcao == "3":
            encerrar_sessao()
        elif opcao == "4":
            exibir_painel_status()
            pausar()
        elif opcao == "5":
            exibir_relatorio_geral()
        elif opcao == "6":
            exibir_log_ocpp()
        elif opcao == "7":
            listar_sessoes()
        elif opcao == "8":
            buscar_sessao_menu()
        elif opcao == "9":
            ordenar_sessoes_menu()
        elif opcao == "10":
            mostrar_estatisticas()
        elif opcao == "11":
            executar_cenario_demo()
        elif opcao == "0":
            print()
            print("  Encerrando o sistema EV ChargeOps...")
            print("  Até logo!")
            print()
            break
        else:
            print("  [!] Opcão inválida. Tente novamente.")
            time.sleep(1)


# =============================================================
#  PONTO DE ENTRADA
# =============================================================

if __name__ == "__main__":
    ocpp_boot_notification()
    pausar()
    menu_principal()
