#Sprint 1: Item 2-b
#Alunos:
#Artur Souza Pereira - RM 570880
#Gustavo Gamba Zancopé - RM 569287
#Isabela Camargo Souza - RM 569196
#Miguel Silvério de Avila - RM 568873
#Victor Vieira Galvão - RM 571483

#Tabela de Distribuição de Frequências - Variável Quantitativa Contínua
from collections import Counter
import pandas as pd

pd.set_option('display.max_columns', None) #para que mostre todas as colunas
pd.set_option('display.width', 1000) #deifinindo a largura do terminal de sáida para mostrar todas as colunas da base

#Configurando o formato de saída da tabela
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

#Leitura da base de dados
base_dados = pd.read_excel("EV_Charging_Stations.xlsx", engine="openpyxl")
#print(base_dados.iloc[0:20])

#Pegando uma coluna da base de dados que representa uma variável quantitativa contínua
quant_continua = base_dados['Charging Capacity (kW)'] #Potência do carregador em quilowatts (kW)
#print(quant_continua)

#Criando a base de dados da potência medida do carregador em quilowatts (kW):
dados = [22]*1205 + [50]*1256 + [150]*1283 + [350]*1256

#Cálculo da Frequência Absoluta (fi)
fi = pd.Series(Counter(dados)).sort_index()
# A predominância de carregadores de alta potência (150 kW e 350 kW) demonstra o foco em tecnologias de
# carregamento rápido, o que reduz o tempo de espera dos usuários e aumenta a eficiência operacional.
# Diferentes níveis de potência (de 22 kW a 350 kW) sugere uma estratégia para atender veículos com diferentes
# capacidades de bateria, perfis de consumo e contextos de utilização.

#Cálculo da Frequência Absoluta Acumulada (fia)
fia = fi.cumsum() #função de cumulative sum, soma acumulada da coluna fi, criada anteriormente

#Cálculo da Frequência Relativa (fr)
fr = 100 * fi / fi.sum()

#Frequencia Realativa acumulada (fra)
fra = fr.cumsum()

#Montando a Tabela de Distribuição de Frequências
tabela = pd.DataFrame({
    'Frequencia_Absoluta': fi,
    'Frequencia_Absoluta_Acumiulada': fia,
    'Frequencia_Relativa': fr,
    'Frequencia_Relativa_Acumulada': fra
})

#Criando o Total na ultima linha:
tabela.loc['Total'] = [
    fi.sum(),
    '-',
    fr.sum(), #valor total da soma
    '-'
]

#Tabela de Distribuição de Frequências:
print("")
print (tabela)
# Estes resultados contribuem para a definição de investimentos futuros em conectores rápidos, expansão estratégica
# da rede, redução do tempo médio de atendimento e aumento da satisfação do usuário.'''



