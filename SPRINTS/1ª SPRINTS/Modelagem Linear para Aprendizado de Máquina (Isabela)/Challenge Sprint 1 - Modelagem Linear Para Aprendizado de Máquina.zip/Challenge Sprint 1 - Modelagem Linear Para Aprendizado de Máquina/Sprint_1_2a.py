#Sprint 1: Item 2-a
#Alunos:
#Artur Souza Pereira - RM 570880
#Gustavo Gamba Zancopé - RM 569287
#Isabela Camargo Souza - RM 569196
#Miguel Silvério de Avila - RM 568873
#Victor Vieira Galvão - RM 571483

#Tabela de Distribuição de Frequências - Variável Quantitativa Discreta
from collections import Counter
import pandas as pd

pd.set_option('display.max_columns', None) #para que mostre todas as colunas
pd.set_option('display.width', 1000) #deifinindo a largura do terminal de sáida para mostrar todas as colunas da base

#Configurando o formato de saída da tabela
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

#Leitura da base de dados
base_dados = pd.read_excel("EV_Charging_Stations.xlsx", engine="openpyxl")
#print(base_dados.iloc[0:20])

#Pegando uma coluna da base de dados que representa uma variável quantitativa discreta
quant_discreta = base_dados['Parking Spots'] #Quantidade de vagas disponíveis para carregamento.
#print(quant_discreta)

#Criando a base de dados das quantidades de vaga disponiveis por estação de carregamento:
dados = [1]*505 + [2]*480 + [3]*477 + [4]*540 + [5]*503 + [6]*479 + [7]*505 + [8]*475 + [9]*542 + [10]*494
# A ausência de estações com grandes quantidades de vagas indica uma estratégia de distribuição geográfica mais ampla,
# focando em aumentar a cobertura da rede em vez de centralizar o atendimento em poucos pontos. Além disso, a maior
# concentração de estações com 4 e 9 vagas indica um foco em atender demandas urbanas e comerciais de fluxo moderado.

#Cálculo da Frequência Absoluta (fi)
fi = pd.Series(Counter(dados)).sort_index()
#A distribuição equilibrada da quantidade de vagas demonstra uma padronização na estrutura das estações.

#Cálculo da Frequência Absoluta Acumulada (fia)
fia = fi.cumsum() #função de cumulative sum, soma acumulada da coluna fi, criada anteriormente

#Cálculo da Frequência Relativa (fr)
fr = 100 * fi / fi.sum()

#Frequencia Realativa acumulada (fra)
fra = fr.cumsum()

#Montando a Tabela de Distribuição de Frequências
tabela = pd.DataFrame({
    'Frequencia_Absoluta': fi,
    'Frequencia_Absoluta_Acumiulada': fia,
    'Frequencia_Relativa': fr,
    'Frequencia_Relativa_Acumulada': fra
})

#Criando o Total na ultima linha:
tabela.loc['Total'] = [
    fi.sum(),
    '-',
    fr.sum(), #valor total da soma
    '-'
]

#Tabela de Distribuição de Frequências:
print("")
print (tabela)
# Esses resultados auxiliam a empresa no planejamento da expansão da rede, definição do tamanho ideal de novas estações,
# análise de custo-benefício da infraestrutura e otimização do espaço urbano.



