# =============================================================
#  EV ChargeOps - Backend (regras de negocio e algoritmos)
#  Desafio Academico FIAP + GoodWe | EV Challenge 2026
#  Sprint 4 - arquivo: estacao.py
#
#  Este arquivo NAO usa print() nem input(): so estruturas de
#  dados, regras de negocio e algoritmos. A interface Web conversa
#  com ele atraves do servidor (servidor.py).
# =============================================================

import random
from datetime import datetime

# --- Constantes ----------------------------------------------
TARIFA_BASE_KWH         = 0.85
TARIFA_PICO_KWH         = 1.25
TARIFA_FORA_PICO_KWH    = 0.65
TAXA_SERVICO            = 1.50
LIMITE_POTENCIA_REDE_KW = 22.0
MAX_CARREGADORES        = 5

TIPOS_USUARIO = {
    "1": {"nome": "Morador",     "desconto": 0.10},
    "2": {"nome": "Visitante",   "desconto": 0.00},
    "3": {"nome": "Funcionario", "desconto": 0.15},
}

CARREGADORES = {
    1: {"potencia_max": 7.4,  "modelo": "GoodWe HCA G2 7kW"},
    2: {"potencia_max": 11.0, "modelo": "GoodWe HCA G2 11kW"},
    3: {"potencia_max": 22.0, "modelo": "GoodWe HCA G2 22kW"},
    4: {"potencia_max": 7.4,  "modelo": "GoodWe HCA G2 7kW"},
    5: {"potencia_max": 11.0, "modelo": "GoodWe HCA G2 11kW"},
}

# Campos pelos quais o historico pode ser ordenado
CRITERIOS_ORDENACAO = ["numero", "energia_kwh", "total", "duracao_min"]


class ErroNegocio(Exception):
    """Erro de regra de negocio (entrada invalida, carregador ocupado...).
    O servidor transforma esse erro em uma resposta HTTP 400."""
    pass


# =============================================================
#  ESTRUTURA DE DADOS DA SESSAO
# =============================================================

class Sessao:
    """Representa uma sessao de recarga ja concluida (historico)."""

    def __init__(self, numero, id_sessao, carregador_id, modelo, usuario,
                 tipo, placa, inicio, fim, duracao_min, potencia,
                 status_demanda, energia_kwh, faixa, tarifa_base,
                 tarifa_final, desconto, custo_energia, taxa_servico, total):
        self.numero         = numero          # ID simples e sequencial (usado em busca/ordenacao)
        self.id_sessao      = id_sessao       # ID tecnico do OCPP
        self.carregador_id  = carregador_id
        self.modelo         = modelo
        self.usuario        = usuario
        self.tipo           = tipo
        self.placa          = placa
        self.inicio         = inicio
        self.fim            = fim
        self.duracao_min    = duracao_min     # tempo de recarga simulado, em minutos
        self.potencia       = potencia
        self.status_demanda = status_demanda
        self.energia_kwh    = energia_kwh
        self.faixa          = faixa
        self.tarifa_base    = tarifa_base
        self.tarifa_final   = tarifa_final
        self.desconto       = desconto
        self.custo_energia  = custo_energia
        self.taxa_servico   = taxa_servico
        self.total          = total

    def to_dict(self):
        """Converte o objeto em dicionario (para virar JSON na API)."""
        return {
            "numero"        : self.numero,
            "id_sessao"     : self.id_sessao,
            "carregador_id" : self.carregador_id,
            "modelo"        : self.modelo,
            "usuario"       : self.usuario,
            "tipo"          : self.tipo,
            "tipo_nome"     : TIPOS_USUARIO[self.tipo]["nome"],
            "placa"         : self.placa.upper(),
            "inicio"        : self.inicio,
            "fim"           : self.fim,
            "duracao_min"   : self.duracao_min,
            "potencia"      : self.potencia,
            "status_demanda": self.status_demanda,
            "energia_kwh"   : self.energia_kwh,
            "faixa"         : self.faixa,
            "tarifa_base"   : self.tarifa_base,
            "tarifa_final"  : self.tarifa_final,
            "desconto"      : self.desconto,
            "custo_energia" : self.custo_energia,
            "taxa_servico"  : self.taxa_servico,
            "total"         : self.total,
        }


# =============================================================
#  ALGORITMOS PROPRIOS (BUSCA E ORDENACAO)
#  Os dois devolvem tambem o numero de comparacoes feitas, para
#  mostrar na demonstracao como o custo cresce com o tamanho da lista.
# =============================================================

def busca_sequencial_por_numero(lista, numero_procurado):
    """
    Busca sequencial (linear) pelo atributo 'numero' de cada Sessao.
    Percorre a lista posicao por posicao ate encontrar o elemento
    ou concluir que ele nao existe.

    Retorna (indice, comparacoes). Indice = -1 se nao encontrou.

    Complexidade: O(n). No pior caso (numero inexistente ou na ultima
    posicao) o laco faz n comparacoes. Dobrar a lista dobra, no pior
    caso, o numero de comparacoes.
    """
    comparacoes = 0
    for i in range(len(lista)):
        comparacoes += 1
        if lista[i].numero == numero_procurado:
            return i, comparacoes
    return -1, comparacoes


def bubble_sort_sessoes(lista, criterio, decrescente=False):
    """
    Bubble Sort implementado manualmente (sem sort()/sorted()).
    Ordena a lista de objetos Sessao IN-PLACE pelo campo 'criterio'
    ("numero", "energia_kwh", "total" ou "duracao_min").

    Retorna (comparacoes, trocas).

    Complexidade: O(n^2). Dois 'for' aninhados fazem n*(n-1)/2
    comparacoes. Dobrar a lista multiplica o numero de comparacoes
    por aproximadamente 4.
    """
    n = len(lista)
    comparacoes = 0
    trocas = 0

    for i in range(n):
        for j in range(n - 1 - i):
            valor_atual   = getattr(lista[j],     criterio)
            valor_proximo = getattr(lista[j + 1], criterio)
            comparacoes += 1

            if decrescente:
                trocar = valor_atual < valor_proximo
            else:
                trocar = valor_atual > valor_proximo

            if trocar:
                lista[j], lista[j + 1] = lista[j + 1], lista[j]
                trocas += 1

    return comparacoes, trocas


# =============================================================
#  TARIFACAO DINAMICA (funcao pura: so calcula)
# =============================================================

def detectar_horario(hora):
    if 18 <= hora <= 20:
        return "pico"
    elif hora >= 23 or hora <= 5:
        return "fora_pico"
    else:
        return "normal"


def calcular_tarifa_dinamica(hora, tipo_key, carga_percentual):
    """
    Combina horario + tipo de usuario + percentual de carga da rede.
    Retorna (tarifa_final, faixa_texto, tarifa_base_ajustada, desconto).
    """
    faixa = detectar_horario(hora)

    if faixa == "pico":
        tarifa = TARIFA_PICO_KWH
        label  = "Pico (18h-21h)"
    elif faixa == "fora_pico":
        tarifa = TARIFA_FORA_PICO_KWH
        label  = "Fora de Pico (23h-06h)"
    else:
        tarifa = TARIFA_BASE_KWH
        label  = "Normal"

    if carga_percentual >= 80:
        ajuste = 0.20
        label += " + alta demanda (+20%)"
    elif carga_percentual >= 50:
        ajuste = 0.10
        label += " + media demanda (+10%)"
    else:
        ajuste = 0.0

    tarifa = tarifa * (1 + ajuste)

    desconto     = TIPOS_USUARIO[tipo_key]["desconto"]
    tarifa_final = round(tarifa * (1 - desconto), 4)

    return tarifa_final, label, round(tarifa, 4), desconto


# =============================================================
#  ESTACAO: guarda o estado do sistema e oferece as operacoes
# =============================================================

class Estacao:

    def __init__(self):
        self.sessoes_ativas = {}   # carregador_id -> dict da sessao em andamento
        self.historico      = []   # lista de objetos Sessao ja encerradas
        self.log_ocpp       = []   # mensagens do protocolo OCPP simulado
        self.proximo_numero = 1    # contador do ID simples das sessoes
        self._contador_msg  = 0
        self._ocpp("BootNotification", {
            "chargePointVendor": "GoodWe",
            "chargePointModel" : "HCA-G2-Multi",
            "chargePointSerial": "GW2026FIAP001",
            "firmwareVersion"  : "2.1.4",
        })

    def reiniciar(self):
        """Apaga tudo e volta ao estado inicial (util para gravar o video)."""
        self.__init__()

    # ----- OCPP simulado -----
    def _ocpp(self, acao, payload):
        """Registra no log uma mensagem CALL e a resposta CALLRESULT."""
        self._contador_msg += 1
        msg_id = "MSG-" + str(self._contador_msg).zfill(6)
        agora  = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
        self.log_ocpp.append({
            "tipo": "CALL", "id": msg_id, "acao": acao,
            "timestamp": agora, "payload": payload,
        })
        self.log_ocpp.append({
            "tipo": "CALLRESULT", "id": msg_id,
            "timestamp": agora, "resultado": "Accepted",
        })
        return msg_id

    def _ocpp_status(self, carregador_id, status):
        self._ocpp("StatusNotification", {
            "connectorId": carregador_id,
            "status"     : status,
        })

    # ----- Controle de demanda -----
    def calcular_carga_total(self):
        total = 0.0
        for s in self.sessoes_ativas.values():
            total += s["potencia_aprovada"]
        return round(total, 2)

    def calcular_potencia_disponivel(self):
        return round(LIMITE_POTENCIA_REDE_KW - self.calcular_carga_total(), 2)

    def percentual_carga(self):
        return round((self.calcular_carga_total() / LIMITE_POTENCIA_REDE_KW) * 100, 1)

    def aplicar_controle_demanda(self, potencia_solicitada):
        """Retorna (potencia_aprovada, status, dado_extra)."""
        disponivel = self.calcular_potencia_disponivel()

        if potencia_solicitada <= disponivel:
            return potencia_solicitada, "OK", None
        elif disponivel > 0.5:
            return round(disponivel, 2), "LIMITADA", disponivel
        else:
            if len(self.sessoes_ativas) > 0:
                reducao = round(
                    (potencia_solicitada - disponivel) / len(self.sessoes_ativas), 2
                )
                return potencia_solicitada, "REDISTRIBUIDA", reducao
            else:
                return 0, "BLOQUEADA", None

    def redistribuir_potencia(self, reducao):
        """Reduz a potencia das sessoes ativas para acomodar uma nova."""
        for cid in self.sessoes_ativas:
            atual = self.sessoes_ativas[cid]["potencia_aprovada"]
            self.sessoes_ativas[cid]["potencia_aprovada"] = max(1.0, round(atual - reducao, 2))
            self._ocpp_status(cid, "ChargingAdjusted")

    # ----- Operacoes de sessao -----
    def iniciar_sessao(self, carregador_id, usuario, placa, tipo, hora, potencia_desejada):
        """Valida os dados, aplica demanda e tarifa, e abre a sessao."""
        try:
            carregador_id     = int(carregador_id)
            hora              = int(hora)
            potencia_desejada = float(potencia_desejada)
        except (TypeError, ValueError):
            raise ErroNegocio("Carregador, hora e potencia devem ser numeros.")

        usuario = str(usuario).strip()
        placa   = str(placa).strip()
        tipo    = str(tipo).strip()

        if carregador_id not in CARREGADORES:
            raise ErroNegocio("Carregador invalido. Escolha de 1 a " + str(MAX_CARREGADORES) + ".")
        if carregador_id in self.sessoes_ativas:
            raise ErroNegocio("Carregador " + str(carregador_id) + " esta ocupado.")
        if not usuario:
            raise ErroNegocio("Nome do usuario nao pode ser vazio.")
        if len(placa) < 5:
            raise ErroNegocio("Placa invalida (minimo 5 caracteres).")
        if tipo not in TIPOS_USUARIO:
            raise ErroNegocio("Tipo de usuario invalido.")
        if not (0 <= hora <= 23):
            raise ErroNegocio("Hora deve estar entre 0 e 23.")

        pot_max = CARREGADORES[carregador_id]["potencia_max"]
        if not (1.0 <= potencia_desejada <= pot_max):
            raise ErroNegocio("Potencia deve estar entre 1.0 e " + str(pot_max) + " kW.")

        percentual = self.percentual_carga()
        pot_ap, status_d, extra = self.aplicar_controle_demanda(potencia_desejada)

        if status_d == "BLOQUEADA":
            self._ocpp_status(carregador_id, "Faulted")
            raise ErroNegocio("Rede sem capacidade no momento. Tente mais tarde.")

        if status_d == "REDISTRIBUIDA":
            self.redistribuir_potencia(extra)
            pot_ap = potencia_desejada

        tarifa_f, faixa, tarifa_b, desc = calcular_tarifa_dinamica(hora, tipo, percentual)

        inicio = datetime.now()
        self._ocpp_status(carregador_id, "Preparing")
        mid = self._ocpp("StartTransaction", {
            "connectorId": carregador_id,
            "idTag"      : usuario,
            "meterStart" : 0,
            "powerLimit" : str(pot_ap) + "kW",
        })

        self.sessoes_ativas[carregador_id] = {
            "id_sessao"          : "CGS-" + inicio.strftime("%Y%m%d%H%M%S") + "-C" + str(carregador_id),
            "carregador_id"      : carregador_id,
            "modelo"             : CARREGADORES[carregador_id]["modelo"],
            "usuario"            : usuario,
            "tipo"               : tipo,
            "tipo_nome"          : TIPOS_USUARIO[tipo]["nome"],
            "placa"              : placa.upper(),
            "hora_tarifacao"     : hora,
            "potencia_solicitada": potencia_desejada,
            "potencia_aprovada"  : pot_ap,
            "status_demanda"     : status_d,
            "faixa"              : faixa,
            "tarifa_base"        : tarifa_b,
            "tarifa_final"       : tarifa_f,
            "desconto"           : desc,
            "energia_kwh"        : 0.0,
            "minutos_simulados"  : 0,
            "inicio"             : inicio.strftime("%H:%M:%S"),
            "ocpp_start_id"      : mid,
        }

        self._ocpp_status(carregador_id, "Charging")
        return self._ativa_publica(carregador_id)

    def _ativa_publica(self, cid):
        """Copia da sessao ativa com o custo parcial calculado."""
        s = dict(self.sessoes_ativas[cid])
        s["custo_parcial"] = round(s["energia_kwh"] * s["tarifa_final"], 2)
        return s

    def atualizar_sessoes(self, minutos):
        """Simula a passagem de tempo: acumula energia nas sessoes ativas."""
        try:
            minutos = int(minutos)
        except (TypeError, ValueError):
            raise ErroNegocio("Minutos deve ser um numero inteiro.")
        if not (1 <= minutos <= 60):
            raise ErroNegocio("Minutos deve estar entre 1 e 60.")
        if not self.sessoes_ativas:
            raise ErroNegocio("Nenhuma sessao ativa para atualizar.")

        for cid in self.sessoes_ativas:
            sessao = self.sessoes_ativas[cid]
            energia_gerada = 0.0
            for m in range(minutos):
                fator = random.uniform(0.95, 1.00)
                energia_gerada += (sessao["potencia_aprovada"] * fator) / 60

            sessao["energia_kwh"]       = round(sessao["energia_kwh"] + energia_gerada, 3)
            sessao["minutos_simulados"] += minutos

            self._ocpp("MeterValues", {
                "connectorId": cid,
                "energyKwh"  : sessao["energia_kwh"],
                "powerKw"    : sessao["potencia_aprovada"],
            })

        return [self._ativa_publica(cid) for cid in self.sessoes_ativas]

    def encerrar_sessao(self, carregador_id):
        """Fecha a sessao, calcula o total e move para o historico."""
        try:
            carregador_id = int(carregador_id)
        except (TypeError, ValueError):
            raise ErroNegocio("Carregador deve ser um numero inteiro.")
        if carregador_id not in self.sessoes_ativas:
            raise ErroNegocio("Carregador " + str(carregador_id) + " nao esta ativo.")

        sessao  = self.sessoes_ativas[carregador_id]
        fim     = datetime.now()
        custo_e = round(sessao["energia_kwh"] * sessao["tarifa_final"], 2)
        total   = round(custo_e + TAXA_SERVICO, 2)

        self._ocpp("StopTransaction", {
            "connectorId": carregador_id,
            "meterStop"  : round(sessao["energia_kwh"] * 1000),
            "totalCost"  : "R$ " + str(total),
            "reason"     : "Local",
        })
        self._ocpp_status(carregador_id, "Available")

        registro = Sessao(
            numero         = self.proximo_numero,
            id_sessao      = sessao["id_sessao"],
            carregador_id  = carregador_id,
            modelo         = sessao["modelo"],
            usuario        = sessao["usuario"],
            tipo           = sessao["tipo"],
            placa          = sessao["placa"],
            inicio         = sessao["inicio"],
            fim            = fim.strftime("%H:%M:%S"),
            duracao_min    = sessao["minutos_simulados"],
            potencia       = sessao["potencia_aprovada"],
            status_demanda = sessao["status_demanda"],
            energia_kwh    = sessao["energia_kwh"],
            faixa          = sessao["faixa"],
            tarifa_base    = sessao["tarifa_base"],
            tarifa_final   = sessao["tarifa_final"],
            desconto       = sessao["desconto"],
            custo_energia  = custo_e,
            taxa_servico   = TAXA_SERVICO,
            total          = total,
        )

        self.historico.append(registro)
        self.proximo_numero += 1
        del self.sessoes_ativas[carregador_id]
        return registro.to_dict()

    # ----- Consultas -----
    def painel_status(self):
        return {
            "limite_kw"      : LIMITE_POTENCIA_REDE_KW,
            "carga_total_kw" : self.calcular_carga_total(),
            "disponivel_kw"  : self.calcular_potencia_disponivel(),
            "percentual"     : self.percentual_carga(),
            "qtd_ativas"     : len(self.sessoes_ativas),
            "qtd_historico"  : len(self.historico),
            "ativas"         : [self._ativa_publica(cid) for cid in self.sessoes_ativas],
            "livres"         : [c for c in CARREGADORES if c not in self.sessoes_ativas],
            "carregadores"   : [
                {"id": c, "modelo": CARREGADORES[c]["modelo"],
                 "potencia_max": CARREGADORES[c]["potencia_max"],
                 "ocupado": c in self.sessoes_ativas}
                for c in CARREGADORES
            ],
        }

    def listar_historico(self):
        return [s.to_dict() for s in self.historico]

    def buscar_sessao(self, numero):
        """Busca sequencial pelo numero (ID) da sessao."""
        try:
            numero = int(numero)
        except (TypeError, ValueError):
            raise ErroNegocio("O numero da sessao deve ser um inteiro.")

        indice, comparacoes = busca_sequencial_por_numero(self.historico, numero)

        resultado = {
            "encontrada"    : indice != -1,
            "numero_buscado": numero,
            "total_sessoes" : len(self.historico),
            "comparacoes"   : comparacoes,
            "indice"        : indice,
            "sessao"        : None,
        }
        if indice != -1:
            resultado["sessao"] = self.historico[indice].to_dict()
        return resultado

    def ordenar_historico(self, criterio, decrescente=False):
        """
        Ordena uma COPIA do historico com Bubble Sort. O historico
        original continua na ordem de encerramento das sessoes.
        """
        if criterio not in CRITERIOS_ORDENACAO:
            raise ErroNegocio("Criterio invalido. Use: " + ", ".join(CRITERIOS_ORDENACAO))

        copia = list(self.historico)
        comparacoes, trocas = bubble_sort_sessoes(copia, criterio, decrescente)

        return {
            "criterio"     : criterio,
            "decrescente"  : bool(decrescente),
            "total_sessoes": len(copia),
            "comparacoes"  : comparacoes,
            "trocas"       : trocas,
            "sessoes"      : [s.to_dict() for s in copia],
        }

    def estatisticas(self):
        quantidade = len(self.historico)
        if quantidade == 0:
            return {"quantidade": 0, "energia_total": 0.0, "faturamento": 0.0,
                    "ticket_medio": 0.0, "maior_consumo": None, "menor_consumo": None}

        energia_total = 0.0
        faturamento   = 0.0
        maior_consumo = self.historico[0].energia_kwh
        menor_consumo = self.historico[0].energia_kwh

        for s in self.historico:
            energia_total += s.energia_kwh
            faturamento   += s.total
            if s.energia_kwh > maior_consumo:
                maior_consumo = s.energia_kwh
            if s.energia_kwh < menor_consumo:
                menor_consumo = s.energia_kwh

        return {
            "quantidade"   : quantidade,
            "energia_total": round(energia_total, 2),
            "faturamento"  : round(faturamento, 2),
            "ticket_medio" : round(faturamento / quantidade, 2),
            "maior_consumo": maior_consumo,
            "menor_consumo": menor_consumo,
        }

    def relatorio_geral(self):
        est = self.estatisticas()
        return {
            "total_sessoes": est["quantidade"],
            "energia_total": est["energia_total"],
            "receita_total": est["faturamento"],
            "historico"    : self.listar_historico(),
            "ativas"       : [self._ativa_publica(cid) for cid in self.sessoes_ativas],
        }

    def obter_log(self, ultimas=20):
        return {
            "total"    : len(self.log_ocpp),
            "mensagens": self.log_ocpp[-ultimas:],
        }

    # ----- Cenario de demonstracao -----
    def executar_demo(self):
        """
        Roda 3 veiculos pelo fluxo completo (iniciar -> simular tempo ->
        encerrar), usando as mesmas funcoes do sistema. Cada chamada
        adiciona 3 sessoes ao historico.
        """
        veiculos = [
            {"nome": "Carlos Lima",   "placa": "EVO1A23", "tipo": "1", "cid": 1, "pot": 7.4,  "hora": 14, "min": 30},
            {"nome": "Ana Souza",     "placa": "BEV2B34", "tipo": "2", "cid": 2, "pot": 11.0, "hora": 19, "min": 45},
            {"nome": "Pedro Martins", "placa": "ZEV3C45", "tipo": "3", "cid": 3, "pot": 7.4,  "hora": 23, "min": 20},
        ]

        numeros_criados = []
        for v in veiculos:
            self.iniciar_sessao(v["cid"], v["nome"], v["placa"], v["tipo"], v["hora"], v["pot"])

        # cada veiculo carrega por um tempo diferente
        for v in veiculos:
            if v["cid"] in self.sessoes_ativas:
                sessao = self.sessoes_ativas[v["cid"]]
                energia = 0.0
                for m in range(v["min"]):
                    energia += (sessao["potencia_aprovada"] * random.uniform(0.95, 1.0)) / 60
                sessao["energia_kwh"]       = round(energia, 3)
                sessao["minutos_simulados"] = v["min"]

        for v in veiculos:
            registro = self.encerrar_sessao(v["cid"])
            numeros_criados.append(registro["numero"])

        return {"numeros_criados": numeros_criados, "total_historico": len(self.historico)}
