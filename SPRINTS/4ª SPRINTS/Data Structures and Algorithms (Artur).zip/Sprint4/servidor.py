# =============================================================
#  EV ChargeOps - Servidor (ponte entre a interface Web e o Python)
#  Desafio Academico FIAP + GoodWe | EV Challenge 2026
#  Sprint 4 - arquivo: servidor.py
#
#  Usa apenas a biblioteca padrao do Python (http.server).
#
#  Fluxo de cada acao na tela:
#     Interface (index.html)  --pedido HTTP/JSON-->  servidor.py
#     servidor.py chama um metodo da Estacao (estacao.py)
#     Estacao processa (estruturas de dados + algoritmos)
#     servidor.py devolve o resultado em JSON  -->  Interface
#
#  Para rodar: execute este arquivo. O navegador abre sozinho em
#  http://127.0.0.1:8000
# =============================================================

import json
import os
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from estacao import Estacao, ErroNegocio

PORTA = 8000
PASTA = os.path.dirname(os.path.abspath(__file__))

# Uma unica estacao guarda todo o estado (sessoes ativas e historico)
estacao = Estacao()
trava   = threading.Lock()   # evita dois pedidos mexendo no estado ao mesmo tempo


class RotaInexistente(Exception):
    pass


def processar(metodo, rota, params, corpo):
    """
    Liga cada rota da API a uma operacao da Estacao.
    Devolve os dados (dict ou list) que viram JSON na resposta.
    """
    if metodo == "GET":
        if rota == "/api/painel":
            return estacao.painel_status()

        if rota == "/api/historico":
            return estacao.listar_historico()

        if rota == "/api/buscar":
            numero = params.get("numero", [""])[0]
            return estacao.buscar_sessao(numero)

        if rota == "/api/ordenar":
            criterio    = params.get("criterio", ["numero"])[0]
            decrescente = params.get("ordem", ["asc"])[0] == "desc"
            return estacao.ordenar_historico(criterio, decrescente)

        if rota == "/api/estatisticas":
            return estacao.estatisticas()

        if rota == "/api/relatorio":
            return estacao.relatorio_geral()

        if rota == "/api/log":
            return estacao.obter_log(20)

    if metodo == "POST":
        if rota == "/api/iniciar":
            return estacao.iniciar_sessao(
                corpo.get("carregador"),
                corpo.get("usuario"),
                corpo.get("placa"),
                corpo.get("tipo"),
                corpo.get("hora"),
                corpo.get("potencia"),
            )

        if rota == "/api/atualizar":
            return estacao.atualizar_sessoes(corpo.get("minutos"))

        if rota == "/api/encerrar":
            return estacao.encerrar_sessao(corpo.get("carregador"))

        if rota == "/api/demo":
            return estacao.executar_demo()

        if rota == "/api/reiniciar":
            estacao.reiniciar()
            return {"mensagem": "Sistema reiniciado."}

    raise RotaInexistente()


class Handler(BaseHTTPRequestHandler):

    # ----- respostas -----
    def _responder(self, status, corpo, tipo):
        self.send_response(status)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(corpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(corpo)

    def _json(self, status, objeto):
        corpo = json.dumps(objeto).encode("utf-8")
        self._responder(status, corpo, "application/json; charset=utf-8")

    # ----- pagina -----
    def _enviar_pagina(self):
        caminho = os.path.join(PASTA, "index.html")
        try:
            with open(caminho, "rb") as f:
                conteudo = f.read()
        except OSError:
            texto = "index.html nao encontrado na pasta do servidor.py".encode("utf-8")
            self._responder(500, texto, "text/plain; charset=utf-8")
            return
        self._responder(200, conteudo, "text/html; charset=utf-8")

    # ----- tratamento comum da API -----
    def _tratar_api(self, metodo, rota, params, corpo):
        try:
            with trava:
                dados = processar(metodo, rota, params, corpo)
            self._json(200, {"ok": True, "dados": dados})
        except ErroNegocio as erro:
            self._json(400, {"ok": False, "erro": str(erro)})
        except RotaInexistente:
            self._json(404, {"ok": False, "erro": "Rota nao encontrada: " + rota})
        except Exception:
            traceback.print_exc()
            self._json(500, {"ok": False, "erro": "Erro interno no servidor."})

    def do_GET(self):
        url    = urlparse(self.path)
        rota   = url.path
        params = parse_qs(url.query)

        if rota == "/" or rota == "/index.html":
            self._enviar_pagina()
        elif rota.startswith("/api/"):
            self._tratar_api("GET", rota, params, {})
        else:
            self._json(404, {"ok": False, "erro": "Rota nao encontrada: " + rota})

    def do_POST(self):
        url  = urlparse(self.path)
        rota = url.path

        try:
            tamanho = int(self.headers.get("Content-Length", 0))
            bruto   = self.rfile.read(tamanho) if tamanho > 0 else b""
            corpo   = json.loads(bruto.decode("utf-8")) if bruto else {}
            if not isinstance(corpo, dict):
                raise ValueError("corpo nao e um objeto JSON")
        except (ValueError, UnicodeDecodeError):
            self._json(400, {"ok": False, "erro": "Corpo da requisicao invalido (JSON esperado)."})
            return

        if rota.startswith("/api/"):
            self._tratar_api("POST", rota, {}, corpo)
        else:
            self._json(404, {"ok": False, "erro": "Rota nao encontrada: " + rota})


def main():
    try:
        servidor = ThreadingHTTPServer(("127.0.0.1", PORTA), Handler)
    except OSError:
        print("Nao foi possivel usar a porta " + str(PORTA) + ".")
        print("Feche o outro servidor que esta rodando ou troque PORTA no topo do arquivo.")
        return

    url = "http://127.0.0.1:" + str(PORTA)
    print("=" * 60)
    print("  EV ChargeOps - servidor no ar")
    print("  Abra no navegador: " + url)
    print("  Para parar: botao Stop do PyCharm (ou Ctrl+C)")
    print("=" * 60)

    threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor encerrado.")
    finally:
        servidor.server_close()


if __name__ == "__main__":
    main()
